<?php

    include "layout.php";
?>

<div class="row">


<div class="leftbox">
   
</div>




<div class="rightbox">
     

</div>


<div class="fullbox">
    

</div>

</div>
<?php
    

    include "layout2.php";

?>