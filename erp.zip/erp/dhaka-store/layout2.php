
<br>
<br>
<br>
<br>
<br>
<br>
<div class="footer noprint">
<p class="col-sm-12 col-12">Developer:kowshiqueroy@gmail.com</p></div>

</div>

<script>
    function openNav() {
        document.getElementById("mySidenav").style.width = "250px";
        document.getElementById("box").style.marginLeft = "0px";
    }

    function closeNav() {
        document.getElementById("mySidenav").style.width = "0";
        document.getElementById("box").style.marginLeft = "0";
    }

    
</script>

<script>
    function myFunction() {
        alert("The form was submitted");
    }




    $(document).ready(function () {
        $(".date").datepicker({
            dateFormat: "yy-mm-dd"
        });});
</script>



</body>

</html>